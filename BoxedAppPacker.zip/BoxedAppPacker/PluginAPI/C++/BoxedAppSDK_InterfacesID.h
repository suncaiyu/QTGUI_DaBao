

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Wed Jul 04 11:11:51 2018
 */
/* Compiler settings for V:\builds\BoxedApp\files\17D2F0AF\trunk\src\BoxedApp\src\BoxedAppSDK\BoxedAppSDK_Interfaces.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_BoxedAppSDK_Interfaces,0x4CF2AA85,0x1267,0x404c,0xAA,0x11,0x6A,0x7A,0x4E,0x24,0xBF,0xC1);


MIDL_DEFINE_GUID(IID, IID_IBxFile,0xD6BECAD0,0x5D56,0x4b51,0x82,0x78,0xD6,0x90,0x47,0x4D,0x69,0xFF);


MIDL_DEFINE_GUID(IID, IID_IBxFileHandle,0x236F1640,0xA96D,0x499c,0xAB,0x32,0x66,0xA7,0x02,0x4F,0x19,0x7E);


MIDL_DEFINE_GUID(IID, IID_IBxReadonlyRegistryWriter,0xA41EE144,0xF5C0,0x429A,0x8B,0xF7,0xE1,0x38,0xFE,0x20,0x8C,0x19);


MIDL_DEFINE_GUID(IID, IID_IBxRegTree,0xE241201E,0x988D,0x4B6B,0x83,0x63,0x48,0x14,0xF2,0x59,0x51,0x20);


MIDL_DEFINE_GUID(IID, IID_IBxRegKeyNode,0xFF182BB8,0x65D4,0x44AE,0xBE,0x4B,0x8E,0xEC,0x82,0xBE,0xC3,0xE4);


MIDL_DEFINE_GUID(IID, IID_IBxRegValueNode,0x456AC3D8,0x8141,0x442A,0x86,0xA3,0x47,0xD3,0xF4,0x21,0x12,0x8C);


MIDL_DEFINE_GUID(IID, IID_IBxEnumRegKeyNode,0x5E9CB505,0x4B76,0x489D,0xAE,0x2B,0xB9,0xE3,0xED,0xF2,0xF3,0x71);


MIDL_DEFINE_GUID(IID, IID_IBxEnumRegValueNode,0x6BEECF3E,0x27E2,0x4906,0xA9,0x20,0x17,0x49,0x34,0xCA,0x35,0x96);


MIDL_DEFINE_GUID(IID, IID_IBxFileHandle2,0xA13C593D,0x835F,0x429d,0x97,0x19,0xE9,0x40,0x09,0x74,0x21,0xFD);


MIDL_DEFINE_GUID(IID, IID_IBxVirtualEnvironment,0xBFC1EEB2,0x8C8B,0x401A,0xB4,0x8A,0x06,0x8F,0x5D,0x83,0x42,0x30);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



